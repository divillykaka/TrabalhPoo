public class Visitante extends Pessoa{
String visitante1;
String visitante2;

public Visitante(String nome, String cpf, int idade){
    super(nome, cpf, idade);
    }
}
