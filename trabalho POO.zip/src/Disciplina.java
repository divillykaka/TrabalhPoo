public class Disciplina {
    String disciplina;

    public Disciplina(String disciplina) {
        this.disciplina = disciplina;

    }
}
